
<?php

// Inialize session
session_start();

// Check, if username session is NOT set then this page will jump to login page
if (!isset($_SESSION['pseudo'])) {
header('Location: index.php');
}

?>
<html>
  <head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="public/css/styles.css"/>
   
    <link rel="stylesheet" href="public/css/skin 2/style.css"/>
    <title> Profil page</title>

  <link rel="stylesheet" href="css/reset.css">

	<script src="js/my_js.js"></script>
    <link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />
    <script src= "public/js/jquery-1.7.1.min.js"></script>
    <script type="text/javascript" src="public/js/raphael-min.js"></script>
    <script type="text/javascript" src="public/js/jquery.easing.js"></script>
    
    
    </head>
<body>
     
          
      <!-- Page content -->
      <div id="cont">
    <div id="header">
      <div class="container">
      
        
      
        <div id ="nav">
      
       	<ul id="menu">
    
        <li>
                <a href="#">Menu</a>
                <ul>
                        
                        <li><a href="#">Programme de fidelité</a></li>
						<li><a href="../voyage.php">Nouveau voyage    </a></li>
              
                </ul>
				
        </li>
		
      
						<li><a href ="chat.php"> Communauté</a></li>
						<li><img width="30"src="../../public/images/avatar.png"/>
						 <ul>
                          <li><a href="#">Vous etiez conducteur</a></li>
						  <li><a href="#">Vous etiez passager</a></li>
                        <li><a href="../preference.php">Vos préférences</a></li>	
						<li><a href="#">Votre profil</a></li>
                </ul></li>
						<li><a> <?php echo $_SESSION['pseudo']; ?> </a>
						
						</li>
						<li><a>A propos</a></li>
						<li><a href="../logout.php">Quitter</a> </li>
</ul>
		
      </div>
      </div>
      
      <div id="nav">
        <form id="searchthis">
      <input id="search" name="q" type="text" placeholder="Entrez une ville" />
				<input id ="search-btn" type="submit" value="   Trouver un départ associé   "/>
        </form>
        </div>
    </div>
<div class="container">
<div class="row">
<div class="col-xs-12">
    
    <div class="main">
            
        <div class="row">
        <div class="col-xs-12 col-sm-6 col-sm-offset-1">
                    
            
 <h1><img height="120"  class="logo" src="../../public/images/logo.gif" /> </h1>
<div id="abc">
<!-- Popup Div Starts Here -->
<div id="popupContact">
<!-- Contact Us Form -->
<h2>Resultats trouvés</h2>
<hr>
<?php 
$Critere = addslashes($_GET["q"]);
$mysqli = new mysqli("localhost", "root", "", "car");
if ($mysqli->connect_errno) {
    echo "Echec lors de la connexion à MySQL : (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

// on se connecte à MySQL 
$res = $mysqli->query("SELECT  * FROM travel WHERE depart LIKE '%$Critere%' OR arrivee LIKE '%$Critere%'");
for ($row_no = $res->num_rows - 1; $row_no >= 0; $row_no--) {
    $res->data_seek($row_no);
    $row = $res->fetch_assoc();
	$login = $row['login'];

  echo "<ul>\n"; 
  echo "<li> Coordonnées du conducteur: ".$row['coordonnees']."</li>\n";
  echo "<br/>";
echo "<li> Place(s) disponible(s): $login </li>\n";
  echo "<br/>";
  echo "<li> Départ proposé par: ".$row['login']."</li>\n";
   echo "<br/>";
   echo "<li> Départ de: ".$row['depart']."</li>\n";
    
     echo "<br/>";
    echo "<li> Arrivée à: ".$row['arrivee']."</li>\n";
	  echo "<br/>";
   echo "<li>Date: ".$row['ladate']."</li>\n"; 
     echo "<br/>";
	   echo "<li> Message du conducteur: ".$row['message']."</li>\n"; 
	     echo "<br/>";
	   echo "<li> Préférences du conducteur: ".$row['preferences']."</li>\n";
	  echo "</ul>";
	    echo "<br/>";
		    echo "<br/>";
			
		//	onclick=\"delete_purchase('" . $row['purch_id'] . "')\"-->

		echo"<CENTER><TABLE width=60% >";
		echo "<TR>";
			 echo"<TD><form method=\"get\" action=\"profilVisite.php\">";
	 echo"<input type=\"hidden\" name=\"varname1\" value = $login>";
	 	 echo "<input  style=\"color:#429398\" value=\"Voir le profil du conducteur\" type=\"submit\">";
		echo "</form></TD>";
		 echo"<TD><form method=\"get\" action=\"reservation1.php\">";
	 echo"<input type=\"hidden\" name=\"varname\" value = ".$row['id'].">";
	 	 echo "<input  style=\"color:#429398\" value=\"Reserver 1 place\" type=\"submit\">";
		echo "</form></TD>";
		echo"<TD><form method=\"get\" action=\"reservation2.php\">";
	 echo"<input type=\"hidden\" name=\"varname\" value = ".$row['id'].">";
	 	 echo "<input type=\"submit\" style=\"color:#429398\" value=\"Reserver 2 places\">";
		echo "</form></TD>";
			echo"<TD><form method=\"get\" action=\"reservation3.php\">";
	 echo"<input type=\"hidden\" name=\"varname\" value = ".$row['id'].">";
	 	 echo "<input type=\"submit\" style=\"color:#429398\" value=\"Reserver 3 places\">";
		echo "</form></TD>";
		

			echo"</TR></TABLE></CENTER>";
			
	
	   echo "<hr>";
	
}


?> 
</div>
<!-- Popup Div Ends Here -->
</div>

  <script src='http://codepen.io/assets/libs/fullpage/jquery.js'></script>

  <script src="js/index.js"></script>

</div>
</div>
</div>
    
<link href="https://fortawesome.github.io/Font-Awesome/assets/font-awesome/css/font-awesome.css" rel="stylesheet">
<!--footer start from here-->
<footer>
  <div class="container">
  
    <div class="row">
        <div class="col-md-2 col-sm-6 footerleft">
    <div class="text-center center-block">
            <br />
                <a href="https://www.facebook.com/uqac.ca/"><i id="social-fb" class="fa fa-facebook-square fa-3x social"></i></a>
              <a href="https://twitter.com/uqac?lang=fr"><i id="social-tw" class="fa fa-twitter-square fa-3x social"></i></a>
              <a href="https://www.linkedin.com/profile/preview?locale=fr_FR&trk=prof-0-sb-preview-primary-button"><i id="social-gp" class="fa fa-linkedin-square fa-3x social"></i></a>
             <a href="https://github.com/mkiam"><i id="social-gp" class="fa fa-github-square fa-3x social"></i></a>
         <a href="mailto:ysoldesanges@@gmail.com"><i id="social-em" class="fa fa-envelope-square fa-3x social"></i></a>
</div>
      </div>
      <div class="col-md-4 col-sm-6 footerleft ">
        
        <br/>
    <p><i class="fa fa-map-pin"></i> Université du QUEBEC à CHICOUTIMI-  QUEBEC, CANADA</p>
        <p><i class="fa fa-phone"></i> Téléphone (CANADA) : +1 418 944 0589</p>
        
        
      </div>

    </div>
  </div>
</footer>
<!--footer start from here-->

<div class="copyright">
  <div class="container">
    <div class="col-md-6">
      <p>© 2016 - MADE BY Karen MIGAN                                      </p>
    </div>
  </div>
</div>


<script type="text/javascript" src="public/js/jquery.fullscreen.js"></script>
<script type="text/javascript">
  $(document).ready(function () {
    $("#background-image").fullscreenBackground();
  });
</script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-30854466-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>  
  </body>
</html>

