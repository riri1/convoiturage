
<?php 
// Inialize session
session_start();

// Check, if username session is NOT set then this page will jump to login page
if (!isset($_SESSION['pseudo'])) {
header('Location: index.php');
}
$login = addslashes($_GET["varname"]);
$tmp2 = 0;
$mysqli = new mysqli("localhost", "root", "", "car");
if ($mysqli->connect_errno) {
    echo "Echec lors de la connexion à MySQL : (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}


// on se connecte à MySQL 
$res1 = $mysqli->query("SELECT  penalite FROM user WHERE login = '$login'");
for ($row_no1 = $res1->num_rows - 1; $row_no1 >= 0; $row_no1--) {
    $res1->data_seek($row_no1);
    $row1 = $res1->fetch_assoc();
  $tmp2 = $row1['penalite']; 


}
if($tmp2 > 0){
echo '<script language="javascript">';
echo 'alert("Cet utilisateur possède encore ses droits")';
echo '</script>'; 
}else{
$tmp2 = $tmp2 + 3;
	$query = "UPDATE user SET penalite = '$tmp2' WHERE login = '$login'";
$mysqli->query($query);
	echo '<script language="javascript">';
echo 'alert("les doirts sont bien réétablis")';
echo '</script>';  
}
   	

?> 