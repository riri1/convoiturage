
<?php 
// Inialize session
session_start();

// Check, if username session is NOT set then this page will jump to login page
if (!isset($_SESSION['pseudo'])) {
header('Location: index.php');
}
$passager = addslashes($_GET["varname"]);
$id = addslashes($_GET["varname1"]);
$idPassager = addslashes($_GET["varname2"]);
$tmp2 = 0;
$tmp = 0;
$mysqli = new mysqli("localhost", "root", "", "car");
if ($mysqli->connect_errno) {
    echo "Echec lors de la connexion à MySQL : (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

// on se connecte à MySQL 
$res = $mysqli->query("SELECT  placeDisponible FROM travel WHERE travel.id = '$id' ");
for ($row_no = $res->num_rows - 1; $row_no >= 0; $row_no--) {
    $res->data_seek($row_no);
    $row = $res->fetch_assoc();
  $tmp = $row['placeDisponible']; 


}
// on se connecte à MySQL 
$res1 = $mysqli->query("SELECT  penalite FROM user WHERE login = '$passager' ");
for ($row_no1 = $res1->num_rows - 1; $row_no1 >= 0; $row_no1--) {
    $res1->data_seek($row_no1);
    $row1 = $res1->fetch_assoc();
  $tmp2 = $row1['penalite']; 


}


$query = "DELETE FROM passagers WHERE pseudoUserpassager = '$passager' AND travel = '$id' AND id = '$idPassager'";
$mysqli->query($query);
$tmp = $tmp + 1;
$tmp2 = $tmp2 - 1;
	$query = "UPDATE travel SET placeDisponible = '$tmp' WHERE travel.id = '$id'";
$mysqli->query($query);
	$query = "UPDATE user SET penalite = '$tmp2' WHERE login = '$passager'";
$mysqli->query($query);
	echo '<script language="javascript">';
echo 'alert("annulation bien effectuée")';
echo '</script>';  
   
	

?> 