
<?php 
// Inialize session
session_start();

// Check, if username session is NOT set then this page will jump to login page
if (!isset($_SESSION['pseudo'])) {
header('Location: index.php');
}
 $Login = $_SESSION['pseudo'];
  $id = addslashes($_GET["varname"]);
   $tmp = 0;
$mysqli = new mysqli("localhost", "root", "", "car");
if ($mysqli->connect_errno) {
    echo "Echec lors de la connexion à MySQL : (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

// on se connecte à MySQL 
$res = $mysqli->query("SELECT  placeDisponible FROM travel WHERE travel.id = '$id' ");
for ($row_no = $res->num_rows - 1; $row_no >= 0; $row_no--) {
    $res->data_seek($row_no);
    $row = $res->fetch_assoc();
  $tmp = $row['placeDisponible']; 


}
if(($tmp-2) < 0){
	echo '<script language="javascript">';
echo 'alert("le nombre de place disponible ne permet pas cette reservation")';
echo '</script>';
}else{
	$query = "INSERT INTO passagers(travel, pseudoUserpassager) VALUES('$id', '$Login')";
	$mysqli->query($query);
	$query = "INSERT INTO passagers(travel, pseudoUserpassager) VALUES('$id', '$Login')";
$mysqli->query($query);
$tmp = $tmp - 2;
	$query = "UPDATE travel SET placeDisponible = '$tmp' WHERE travel.id = '$id'";
$mysqli->query($query);
	echo '<script language="javascript">';
echo 'alert("reservation bien effectuée")';
echo '</script>';  
   
	
}

?> 