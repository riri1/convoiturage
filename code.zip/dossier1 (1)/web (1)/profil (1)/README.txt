A Pen created at CodePen.io. You can find this one at http://codepen.io/nrdobie/pen/sfvdm.

 This is a social network profile header that was done entirely in CSS and HTML.