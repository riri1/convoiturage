// Validating Empty Field
function reserver() {
	var btn = document.getElementById('search-btn1');
btn.addEventListener('click', function() {
  document.location.href = '../reservation1.php';
});

}
function reserver1(){
		var btn = document.getElementById('search-btn2');
btn.addEventListener('click', function() {
  document.location.href = '../reservation2.php';
});

}
function reserver2() {
		var btn = document.getElementById('search-btn3');
btn.addEventListener('click', function() {
  document.location.href = '../reservation3.php';
});

}


