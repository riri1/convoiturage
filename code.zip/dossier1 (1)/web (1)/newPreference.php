

 <html>
 <?php

// Inialize session
session_start();

// Check, if username session is NOT set then this page will jump to login page
if (!isset($_SESSION['pseudo'])) {
header('Location: index.php');
}

// on se connecte à MySQL 
$db = mysql_connect('localhost', 'root', ''); 

// on sélectionne la base 
mysql_select_db('car',$db); 
 $Login = $_SESSION['pseudo'];
 $Fumeur= addslashes($_GET["group1"]);
 $Animaux= addslashes($_GET["group2"]);
 $Satisfait = addslashes($_GET["group3"]);





// on crée la requête SQL 
$sql = "INSERT INTO preference (login, fumeur, animaux, satisfait) VALUES('$Login', '$Fumeur', '$Animaux', '$Satisfait')";

// on envoie la requête 
$req = mysql_query($sql) or die('Erreur SQL !<br>'.$sql.'<br>'.mysql_error()); 

 
   	//redirect back to our list page since the insert worked
        header("location: menu.php");   
   

// on ferme la connexion à mysql 
mysql_close(); 
?> 
 
 </html>