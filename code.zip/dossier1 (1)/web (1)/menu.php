<!DOCTYPE html>

<?php

// Inialize session
session_start();

// Check, if username session is NOT set then this page will jump to login page
if (!isset($_SESSION['pseudo'])) {
header('Location: index.php');
}

?>
<html>
	<head>

		<title>iView&trade; v2.0</title>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<link rel="stylesheet" href="../public/css/styles.css"/>
		<link rel="stylesheet" href="../public/css/iview.css"/>
		<link rel="stylesheet" href="../public/css/skin 2/style.css"/>
		<script src= "../public/js/jquery-1.7.1.min.js"></script>
		<script type="text/javascript" src="../public/js/raphael-min.js"></script>
		<script type="text/javascript" src="../public/js/jquery.easing.js"></script>
		<script src="../public/js/iview.js"></script>
		<script>
			$(document).ready(function(){
				$('#iview').iView({
					pauseTime: 7000,
					pauseOnHover: true,
					directionNav: true,
					directionNavHide: false,
					directionNavHoverOpacity: 0,
					controlNav: false,
					nextLabel: "Nächste",
					previousLabel: "Vorherige",
					playLabel: "Spielen",
					pauseLabel: "Pause",
					timer: "360Bar",
					timerPadding: 3,
					timerColor: "#0F0"
				});
				$('#iview2').iView({
					pauseTime: 7000,
					pauseOnHover: true,
					directionNav: true,
					directionNavHide: false,
					controlNav: true,
					controlNavNextPrev: false,
					controlNavTooltip: false,
					nextLabel: "Próximo",
					previousLabel: "Anterior",
					playLabel: "Jugada",
					pauseLabel: "Pausa",
					timer: "360Bar",
					timerBg: "#EEE",
					timerColor: "#000",
					timerDiameter: 40,
					timerPadding: 4,
					timerStroke: 8,
					timerPosition: "bottom-right"
				});
			});
		</script>
		</head>
<body>
         <!-- Sidebar -->
      <div id="sidebar-wrapper">
      <ul id="sidebar_menu" class="sidebar-nav">
           <li class="sidebar-brand"><a id="menu-toggle" href="#">Top des départs</a></li>
      </ul>
        <ul class="sidebar-nav" id="sidebar">     
          <li><a><img src="../public/images/rec1.jpg")' height="92" width="132"/></a></li>
          
          <li><a>Montréal à 20$</a></li>
		  <li><a><img src="../public/images/REC3.jpg" height="92" width="132"/></a></li>
          <li><a>Québec à 25$</a></li>
		  <li><a><img src="../public/images/REC4.jpg" height="92" width="132"/></a></li>
          <li><a>Shawinigan à 30$</a></li>
		  <li><a><img src="../public/images/rec2.jpg" height="92" width="132"/></a></li>
          <li><a>Vancouver à 60$</a></li>
		  
		  <li><a><img src="../public/images/rec5.jpg" height="92" width="132"/></a></li>
          <li><a>Gatineau à 16$</a></li>
		    <li><a><img src="../public/images/rec6.jpg" height="92" width="132"/></a></li>
          <li><a>Ottawa à 76$</a></li>
		    <li><a><img src="../public/images/rec7.jpg" height="92" width="132"/></a></li>
          <li><a>Trois-rivières à 86$</a></li>
        </ul>
      </div>
          
      <!-- Page content -->
      <div id="cont">
		<div id="header">
			<div class="container">
			
				
			
				<div id ="nav">
      
				<ul id="menu">
    
        <li>
                <a href="#">Menu</a>
                <ul>
                        
                        <li><a href="#">Programme de fidélité</a></li>
						<li><a href="voyage.php">Nouveau voyage    </a></li>
              
                </ul>
				
        </li>
		
      
						<li><a href ="#"> Communauté</a></li>
						<li><img width="30"src="../public/images/avatar.png"/>
						 <ul>
                          <li><a href="#">Vous etiez conducteur</a></li>
						  <li><a href="#">Vous etiez passager</a></li>
                        <li><a href="preference.php">Vos préférences</a></li>	
						<li><a href="profil/profil.php">Votre profil</a></li>
                </ul></li>
						<li><a> <?php echo $_SESSION['pseudo']; ?> </a>
						
						</li>
						<li><a>A propos</a></li>
						<li><a href="logout.php">Quitter</a> </li>
</ul>
			</div>
			</div>
			
			<div id="nav">
				<form id="searchthis" action="profil/searching.php" id="form" method="get">
				<input id="search" name="q" type="text" placeholder="Entrez une ville" />
				<input id ="search-btn" type="submit" value="Trouver un voyage associé"/>
				</form>
				</div>
		</div>
		
		
<div class="container">
<div class="row">
<div class="col-xs-12">
    
    <div class="main">
            
        <div class="row">
        <div class="col-xs-12 col-sm-6 col-sm-offset-1">
                    
            
	<div id="iview">
	<div data-iview:image="../public/photos/p3.jpg" height="400" width="900">
				<div class="iview-caption video-caption" data-x="50" data-y="50" data-transition="wipeUp"><iframe src="https://www.youtube.com/embed/Zb3R2uh9MMM"  width="250" height="181" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe></div>
				<div class="iview-caption caption4" data-x="600" data-y="140" data-transition="wipeRight">Au volant</div>
				<div class="iview-caption caption3" data-x="600" data-y="200" data-width="235" data-height="40" data-transition="wipeLeft">On evite les appels téléphoniques!</br><b>La blonde attendra qu'on soit à la maison!</b></div>
			</div>
			<div data-iview:image="../public/photos/p1.jpg" height="400" width="900">>
				<div class="iview-caption caption1" data-x="300" data-y="300" data-transition="expandLeft">Elle était juste au mauvaix endroit!</div>
			</div>

			

			<div data-iview:image="../public/photos/p2.jpg" height="400" width="900">>
				<div class="iview-caption caption2" data-x="400" data-y="320" data-transition="wipeRight">On reste sobre, on reste en vie!</div>
			</div>

			<div data-iview:image="../public/photos/p4.jpg" height="400" width="900">>
				<div class="iview-caption" data-x="120" data-y="320" data-transition="wipeLeft">Moins de vitesse, moins de drames!</div>
			</div>

			<div data-iview:image="../public/photos/p5.jpg" height="400" width="900">>
				<div class="iview-caption caption3" data-x="250" data-y="350" data-transition="wipeLeft">Texter est mortel! .</div>
			</div>
		</div>
		
        </div>
        </div>
        
    </div>
</div>
</div>
</div>
		
<link href="https://fortawesome.github.io/Font-Awesome/assets/font-awesome/css/font-awesome.css" rel="stylesheet">
<!--footer start from here-->
<footer>
  <div class="container">
  
    <div class="row">
	      <div class="col-md-2 col-sm-6 footerleft">
        <h6 class="heading7"><img class = "logo" src="../public/images/logo.gif"/></h6>
    <div class="text-center center-block">
            <br />
                <a href="https://www.facebook.com/uqac.ca/"><i id="social-fb" class="fa fa-facebook-square fa-3x social"></i></a>
	            <a href="https://twitter.com/uqac?lang=fr"><i id="social-tw" class="fa fa-twitter-square fa-3x social"></i></a>
	            <a href="https://www.linkedin.com/profile/preview?locale=fr_FR&trk=prof-0-sb-preview-primary-button"><i id="social-gp" class="fa fa-linkedin-square fa-3x social"></i></a>
	           <a href="https://github.com/mkiam"><i id="social-gp" class="fa fa-github-square fa-3x social"></i></a>
			   <a href="mailto:ysoldesanges@@gmail.com"><i id="social-em" class="fa fa-envelope-square fa-3x social"></i></a>
</div>
      </div>
      <div class="col-md-4 col-sm-6 footerleft ">
        
        <br/>
		<p><i class="fa fa-map-pin"></i> Université du QUEBEC à CHICOUTIMI-  QUEBEC, CANADA</p>
        <p><i class="fa fa-phone"></i> Téléphone (CANADA) : +1 418 944 0589</p>
        
        
      </div>

    </div>
  </div>
</footer>
<!--footer start from here-->

<div class="copyright">
  <div class="container">
    <div class="col-md-6">
      <p>© 2016 - MADE BY Karen MIGAN                                                          </p>
    </div>
  </div>
</div>


<script type="text/javascript" src="../public/js/jquery.fullscreen.js"></script>
<script type="text/javascript">
	$(document).ready(function () {
		$("#background-image").fullscreenBackground();
	});
</script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-30854466-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

	
	</body>
</html>