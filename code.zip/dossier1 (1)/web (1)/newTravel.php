

 <html>


<?php 
// Inialize session
session_start();

// Check, if username session is NOT set then this page will jump to login page
if (!isset($_SESSION['pseudo'])) {
header('Location: index.php');
}

// on se connecte à MySQL 
$db = mysql_connect('localhost', 'root', ''); 

// on sélectionne la base 
mysql_select_db('car',$db); 
 $Login = $_SESSION['pseudo'];
 $Horaire= addslashes($_GET["hour"]);
  $Depart= addslashes($_GET["depart"]);
   $Arrivee= addslashes($_GET["arrivee"]);
 $Date= addslashes($_GET["date"]);
 $Message = addslashes($_GET["message"]);
 $Preference = addslashes($_GET["preference"]);
  $Coordonnees = addslashes($_GET["coordonnees"]);




// on crée la requête SQL 
$sql = "INSERT INTO travel (coordonnees, placeDisponible, login, horaire, ladate, message, preferences, depart, arrivee) VALUES('$Coordonnees', 3, '$Login', '$Horaire', '$Date', '$Message', '$Preference', '$Depart', '$Arrivee')";

// on envoie la requête 
$req = mysql_query($sql) or die('Erreur SQL !<br>'.$sql.'<br>'.mysql_error()); 

 
   	//redirect back to our list page since the insert worked
        header("location: menu.php");   
   

// on ferme la connexion à mysql 
mysql_close(); 
?> 
 
 </html>