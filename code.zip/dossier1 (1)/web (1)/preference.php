
<!DOCTYPE html>
<html>
<?php

// Inialize session
session_start();

// Check, if username session is NOT set then this page will jump to login page
if (!isset($_SESSION['pseudo'])) {
header('Location: index.php');
}

?>
<head>
<title>Popup contact form</title>
<link rel="stylesheet" href="../public/css/elements.css"/>
<script src="js/my_js.js"></script>
</head>
<!-- Body Starts Here -->
<body id="body" style="overflow:hidden;">
<div id="abc">
<!-- Popup Div Starts Here -->
<div id="popupContact">
<!-- Contact Us Form -->
<form action="newPreference.php" id="form" method="get" name="form">
<img id="close" src="../public/photos/close.png" onclick ="location.href = 'menu.php';">
<h2>Preferences</h2>
<hr>
<input id = "name" type="radio" value="oui" name="group1"> Fumeur<br/>
<input id = "email" type="radio" value="non" name="group1">Non fumeur<br/>
<hr>
<input id = "email" type="radio" value="oui" name="group2">Animaux<br/>
<input id = "name" type="radio"  value="non" name="group2">Pas d'animaux<br/>

<hr>
<input id = "msg" type="radio" value="oui" name="group3"> Satisfait<br/>
<input id = "name" type="radio" value="non" name="group3">Pas Satisfait<br/>
<hr>
<hr>
<a href="javascript:%20check_empty()" id="submit">Valider</a>

</form>
</div>
<!-- Popup Div Ends Here -->
</div>
<!-- Display Popup Button -->
<button id="popup" onclick="div_show()">Passer aux prefrences</button>
</body>
<!-- Body Ends Here -->
</html>