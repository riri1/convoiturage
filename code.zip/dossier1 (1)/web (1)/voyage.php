
<!DOCTYPE html>
<html>
<head>
<title>Popup contact form</title>
<link rel="stylesheet" href="../public/css/elements.css"/>
<script src="js/my_js.js"></script>
</head>
<!-- Body Starts Here -->
<body id="body" style="overflow:hidden;">
<div id="abc">
<!-- Popup Div Starts Here -->
<div id="popupContact">
<!-- Contact Us Form -->
<form action="newTravel.php" id="form" method="get" name="form">
<img id="close" src="../public/photos/close.png" onclick ="location.href = 'menu.php'">
<h2>Nouveau voyage</h2>
<hr>
<input id="name" name="hour" placeholder="Horaire" required type="text">
<input id="email" name="date" placeholder="Date" required  type="text">
<input id="name" name="depart" placeholder="Départ" required type="text">
<input id="email" name="arrivee" placeholder="Arrivée" required  type="text">
<textarea id="msg" name="coordonnees" required placeholder="Coordonnées"></textarea>

<textarea id="msg" name="preference" required placeholder="Preferences"></textarea>

<textarea id="msg" name="message" required placeholder="Message"></textarea>
<a href="javascript:%20check_empty()" id="submit">Valider</a>
</form>
</div>
<!-- Popup Div Ends Here -->
</div>
<!-- Display Popup Button -->
<button id="popup" onclick="div_show()">Personnalisez votre départ</button>
</body>
<!-- Body Ends Here -->
</html>